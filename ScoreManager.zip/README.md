# Score Manager

Web application to manage student's score