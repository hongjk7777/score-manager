import express from "express";
import passport from "passport";
import bodyParser from "body-parser";
import session from "express-session";
import MySQLStore from "express-mysql-session";
import compression from "compression";
import classRouter from "./public/classes/class.js";
import adminRouter from "./public/classes/classList.js";
import {router as authRouter, isAuthenticated} from "./public/auth/auth.js";
import settingsRouter from "./public/settings/profile.js";
// import engines from "consolidate";
// import functions from "firebase-functions"


//

// import firebase from "firebase";

// const app = firebase.initializeApp({
//     apiKey: "AIzaSyCw_c1Vc1lirHPv1CAq-Pp_orTcT1v1Upw",
//     authDomain: "do-it-edu.firebaseapp.com",
//     projectId: "do-it-edu",
//     storageBucket: "do-it-edu.appspot.com",
//     messagingSenderId: "27875531148",
//     appId: "1:27875531148:web:09a9966fce5850952a9ea9",
//     measurementId: "G-J75B7D8Z5F"
// });




const app = express();
const port = process.env.PORT || 8081;

//gzip/deflate outgoing responses
app.use(compression());

//setup bodyparser 
app.use(bodyParser.json());
app.use(express.urlencoded({extended : false}));

//setup session 
const options = {
  host: "localhost",
  port: 3306,
  user: "root",
  password: "0219JK0114WK!@",
  database: "sessiondb",
};

const sessionStore = new MySQLStore(options);

app.use(
  session({
      secret: "user key",
      store: sessionStore,
      resave: false,
      saveUninitialized: false,
  })
);

//setup passport
app.use(passport.initialize());
app.use(passport.session());

//set up view engine and file dir
// app.engine('html', engines.mustache);
// app.set("view engine", "html);
app.set("view engine", "pug");
app.set("views", __dirname + "/public/views/pug");


app.use("/public", express.static(__dirname + "/public"));
// app.use(express.static(__dirname + "/public/views"));

app.get("/", (req, res) => {
  res.render("home", {authentication : req.isAuthenticated(), user: req.user});
});

app.use("/health", function(req, res) {
  res.send({'title': 'success'});
});

//set routers
app.use("/", authRouter);
app.use("/class", classRouter);
app.use("/classList", adminRouter);
app.use("/settings", settingsRouter);


app.listen(port, () => {
    console.log(`start ${port}`);
});


// app.use(passport.authenticate('session'));
// const api = functions.https.onRequest(app);
// module.exports(api);
