const logoBtn = document.querySelector("#logo");

logoBtn.addEventListener("click", (e) => {
    location.href=`/`;
})